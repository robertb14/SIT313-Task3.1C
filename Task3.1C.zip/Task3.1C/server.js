//Robert Bajan 30/08/21
const { response } = require("express")
const express = require("express")
const validator = require("validator")
const bodyParser = require("body-parser")
const mongoose = require("mongoose")
const https = require("https")
const app = express()

app.use(express.static("Public"))
app.use(bodyParser.urlencoded({extended:true}))

mongoose.connect("mongodb://localhost:27017/iService")      //Sets up the local database
    
    const userSchema = new mongoose.Schema(             //Sets up the MongoDB Schema
        {
            first:{
                type: String,
                required: true
            },
            last:{
                type: String,
                required: true
            },
            email:{
                type: String,
                required: true,
                // lowercase: true,
                // index: { unique: true },
                // validate: [validator.isEmail, "The email provided is not valid"],
                // validate(value) {
                //     if (!validator.isEmail(value)){
                //         throw new Error("The email provided is not valid")
                //     }
                // }
            },
            residence:{
                type: String,
                required: true
            },
            password:{
                type: String,
                required: true,
                minlength: 8
            },
            conpassword:{
                type: String,
                required: true,
                minlength: 8
            },
            address:{
                type: String,
                required: true
            },
            city:{
                type: String,
                required: true
            },
            state:{
                type: String,
                required: true
            },
            postal:{
                type: Number,
                required: false,
                minlength: 4,
                maxlength: 4
            },
            mobile:{
                type: Number,
                required:false
            }
        }
    )

    const User = mongoose.model('Users', userSchema)         //Turns the schema into a usable model
    

app.get('/', (req, res)=> {             //Retrieves the html file and presents in on the local server via the web browser
    res.sendFile(__dirname + "/index.html")
})

app.post('/', (req, res)=> {            //Retrieves the post from the web server
    const first = req.body.first
    const last = req.body.last
    const email = req.body.email
    const residence = req.body.residence
    const password = req.body.password
    const conpassword = req.body.conpassword
    const address = req.body.address
    const city = req.body.city
    const state = req.body.state
    const postal = req.body.postal
    const mobile = req.body.mobile

    if(!validator.equals(password, conpassword)) {
        res.status(400).send("Passwords do not match")
    }
    else {
        const NewUser = new User(
        {
            first: first,
            last: last,
            email: email,
            residence: residence,
            password: password,
            conpassword: conpassword,
            address: address,
            city: city,
            state: state,
            postal: postal,
            mobile: mobile
        }
    )
        NewUser.save((err)=>{           //Prints the data into the selected database
            if(err)
            {console.log(err)}
            else
            {console.log("Inserted Successfully")}
        })
    }
    
    const data = {              //Collates the data that will be used by the api
        members: [{
            email_address: email,
            status: "subscribed",
            merge_fields: {
                FNAME: first,
                LNAME: last
            }
        }]
    }

    jsonData = JSON.stringify(data)             //Converts the data into JSON format

    const url = "https://us5.api.mailchimp.com/3.0/lists/6436f26f25"

    const options = {           //Defines the options
        method: "POST",
        auth: "azi:2d2bed9e1e9b04241074f1aede0865bd-us5"
    }

    const request = https.request(url, options, (response)=> {
        response.on("data", (data)=> {
            console.log(JSON.parse(data))
        })
    })

    request.write(jsonData)
    request.end()

    res.send("I am posting now")
})

app.listen(3000, function (request, response) {
    console.log("Server is running on port 3000")
})